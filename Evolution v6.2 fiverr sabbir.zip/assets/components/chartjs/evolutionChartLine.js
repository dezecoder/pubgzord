(function ($) {
    $.fn.evolutionChartLine = function(options){
        var settings = $.extend({}, $.fn.evolutionChartLine.defaults, options);
        this.each(function(){
            var ctx = $(this);
            var myChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: settings.labels_data,
                    datasets: [{
                        label: settings.data_label,
                        backgroundColor: [
                            settings.backgroundColor
                        ],
                        borderColor: [
                            settings.borderColor
                        ],
                        data: settings.full_data,
                        borderWidth: settings.borderWidth,
                        fill: false
                    }]
                },
                options: {
                    scales: {
                        yAxes: [{
                            ticks: {
                                beginAtZero:true
                            }
                        }]
                    }
                }
            });
        });
    };
    $.fn.evolutionChartLine.defaults = {
        data_label: '',
        labels_data: '',
        full_data: '',
        backgroundColor: 'rgb(255, 99, 132)',
        borderColor: 'rgba(255,99,132,1)',
        borderWidth: 1
    };
})(jQuery);