$(function(){
	$('.date_picker').datepicker();
	checkall();
	notifications();
});

function notifications() {
	$.get(adminNotificationUrl, function( data ) {
		total_notifications = 0;
		text_notifications = '';

		$.each(data, function (i, item) {
			total_notifications = total_notifications+1;
			text_notifications += "<a class=\"dropdown-item\" href=\""+item.link+"\">\n" +
				"                                    <div class=\"notification__icon-wrapper\">\n" +
				"                                        <div class=\"notification__icon\">\n" +
				"                                            <i class=\""+item.icon+"\"></i>\n" +
				"                                        </div>\n" +
				"                                    </div>\n" +
				"                                    <div class=\"notification__content\">\n" +
				"                                        <span class=\"notification__category\">"+item.title+"</span>\n" +
				"                                        <p>"+item.message+"</p>\n" +
				"                                    </div>\n" +
				"                                </a>";
		});
		if(total_notifications > 0){
			$("#notification_bell").html('<span class="badge badge-pill badge-danger">'+total_notifications+'</span>');
			$("#notification_list").html(text_notifications);
		}
	});
}

function checkall(){
    $('#checkall').change(function(){
        var checkboxes = $(this).closest('form').find('.checkall');
        if($(this).prop('checked')) {
            checkboxes.prop('checked', true);
        } else {
            checkboxes.prop('checked', false);
        }
    });

    $('#checkall2').change(function(){
        var checkboxes = $(this).closest('form').find('.checkall2');
        if($(this).prop('checked')) {
            checkboxes.prop('checked', true);
        } else {
            checkboxes.prop('checked', false);
        }
    });
}

function selectowner(){
	var owner = $("#owner").val();
	if(owner == 'single'){
		$("#username").fadeIn();
	}else{
		$("#username").fadeOut();
	}
}

function receivertype(){
	var receiverlist = $("#receiverlist").val();
	if(receiverlist != 'single'){
		$("#singlemember").fadeOut();
		$("#maxperpage").fadeIn();
	}else{
		$("#singlemember").fadeIn();
		$("#maxperpage").fadeOut();
	}
}
function save_notes() {

	$('#adminNoteForm').submit();
}

