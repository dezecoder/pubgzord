var ad_initialized = false;
$(function(){
	if (top != self) {
		try { top.location = self.location; }
		catch (err) { self.location = '/'; }
	}
	$("#surf_status").html('<div class="adwait">'+adwait+'</div>');
});
function ptc_auto_load(error_msg, secs) {
	if(secs > 0){
		secsr = secs*1000;
		window.setTimeout("ptc_initialize('"+error_msg+"')",secsr);
	}
}
function ptc_initialize(error){
	if(ad_initialized === true){
		return false;
	}
	ad_initialized = true;
	if(error == ''){
		$(".adwait").fadeOut(1000, function(){
			$("#surf_status").html('');
			$("#surfer_bar").show();
			progressBar.setCallback(function () {
				$("#surfer_bar").remove();
				$("#surf_status").fadeOut('slow', function(){
					$("#captchaBlock").fadeIn('slow');
				});
			});
			progressBar.start(ad_seconds);
		});
	}else{
		$(".adwait").fadeOut(1000, function(){
			$("#surf_status").html("<div class='errorbox'>"+error+"</div>");
			$(".errorbox").fadeIn(1000);
		});
	}
}

function ptc_validate(master_key){
	if(master_key==''){
		$("#surf_status").fadeOut('slow', function(){
			$("#captchaBlock").fadeIn('slow');
		});
		return false;
	}else{
		$("#captchaBlock").fadeOut('slow', function(){
			$(this).remove();
			$("#surf_status").fadeIn('slow');
		});

	}
	$("#surf_status").html("Please wait...");
	$("#ad_token").val(master_key);

	dataForm = new FormData(document.getElementById('ptc_form'));
	$.ajax({
		url: $('ptc_form').attr('action'),
		method: 'POST',
		data: dataForm,
		dataType: 'json',
		cache: false,
		processData: false,
		contentType: false
	}).done(function(data) {
		if(data.status == 'success'){
			$("#surf_status").html("<div class='successbox'>"+data.msg+"</div>");
			$(".successbox").fadeIn('slow');
			if(data.script){
				eval(data.script);
			}
		}else{
			$("#surf_status").html("<div class='errorbox'>"+data.msg+"</div>");
			$(".errorbox").fadeIn('slow');
		}
	}).fail(function(jqXHR, textStatus, errorThrown) {
		$("#surf_status").html("<div class='errorbox'>Something was wrong, refresh this page.</div>");
		$(".errorbox").fadeIn('slow');
	});
}

function ptc_browser() {
	var int=self.setInterval("upp()",100);
}

function upp(){
	if(ad_initialized !== true){
		return false;
	}
	var w=window;
	var d=document;
	lwf=((typeof d.hasFocus!='undefined'?d.hasFocus():wf)?1:0);
	if(lwf == 1){
		progressBar.resume();
	}else{
		progressBar.pause();
	}
}