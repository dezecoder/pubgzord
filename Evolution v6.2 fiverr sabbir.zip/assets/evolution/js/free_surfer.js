var w=window;
var d=document;
advertisementID=0;
secondsLoaded = 0;
adLoaded = false;
adConfirmed = false;
adSessToken = null;
adTimer = 0;

function openAd(adId, iFrame)
{
    advertisementID = adId;
    adWindow = window.open('/view_ads/token/'+adId, '_blank');
    if(iFrame === 2){
        var myModal = new bootstrap.Modal(document.getElementById('ptcAddModal'), {
            keyboard: false,
            backdrop: 'static'
        })
        myModal.show();
        secondsLoaded = 0;
        myInterval = setInterval('checkOpenedAd();', 1000);
    }
}
function adWindowOpened(sessToken, adSeconds) {
    adLoaded = true;
    adTimer = parseInt(adSeconds);
    adSessToken = sessToken;
}
function adWindowOpenedError(errorMsg) {
    showAdWarningMsg('Error: '+errorMsg);
    clearInterval(myInterval);
}
function checkOpenedAd() {
    if(!adWindow){
        showAdWarningMsg(msgModalBlocker);
        clearInterval(myInterval);
    }else{
        if(!adWindow.closed){
            timeLeft = adTimer-secondsLoaded;
            if(adLoaded === true){
                if(timeLeft >= 0){
                    showCounterMsg(adTimer-secondsLoaded);
                    secondsLoaded = secondsLoaded+1;
                }else{

                    $.ajax({
                        url: '/view_ads/token/'+advertisementID+'/'+adSessToken+'?getMagic=code',
                        method: 'GET',
                        dataType: 'json',
                        cache: false,
                        processData: false,
                        contentType: false
                    }).done(function(data) {
                        if(data.status == 'success'){
                            $('#adSessToken').val(data.script);
                            showConfirmationMsg(data.msg);
                        }else{
                            showAdWarningMsg(msgModalWrongAccess);
                        }
                    }).fail(function(jqXHR, textStatus, errorThrown) {
                        showAdWarningMsg(msgModalWrongAccess);
                    });

                    clearInterval(myInterval);
                }
            }
        }else{
            if(adConfirmed === true){
                console.log('Ad was closed.');
            }else{
                showAdWarningMsg(msgModalAdClosed);
            }
            clearInterval(myInterval);
        }
    }
}

function ptc_validate(master_key){
    if(master_key==''){
        $("#surf_status").fadeOut('slow', function(){
            $("#captchaBlock").fadeIn('slow');
        });
        return false;
    }else{
        $("#captchaBlock").fadeOut('slow', function(){
            $(this).remove();
            $("#surf_status").fadeIn('slow');
        });
    }
    showAdWarningMsg(msgPleaseWait);
    $("#adSelectedToken").val(master_key);

    dataForm = new FormData(document.getElementById('ptc_form'));
    $.ajax({
        url: '/view_ads/token/'+advertisementID+'/'+adSessToken,
        method: 'POST',
        data: dataForm,
        dataType: 'json',
        cache: false,
        processData: false,
        contentType: false
    }).done(function(data) {
        showAdWarningMsg(data.msg);
        hideAdvertisement(advertisementID);
    }).fail(function(jqXHR, textStatus, errorThrown) {
        showAdWarningMsg(msgModalWrongAccess);
    });
}


function showCounterMsg(adMsg) {
    $('#modalCounterLine').text(adMsg);
    $('#modalCounterMsg').show();
    $('#modalWarningMsg').hide();
    $('#modalWaitMsg').hide();
    $('#modalConfirmationMsg').hide();
}

function showAdWarningMsg(adMsg) {
    $('#modalWarningLine').text(adMsg);
    $('#modalWarningMsg').show();
    $('#modalWaitMsg').hide();
    $('#modalCounterMsg').hide();
    $('#modalConfirmationMsg').hide();
}

function showConfirmationMsg(adMsg) {
    $('#modalConfirmationLine').html(msgUpside+'<br>'+adMsg);
    $('#modalConfirmationMsg').show();
    $('#modalWaitMsg').hide();
    $('#modalWarningMsg').hide();
    $('#modalCounterMsg').hide();
}

function closeAdModal() {
    var myModal = bootstrap.Modal.getInstance(document.getElementById('ptcAddModal'))
    myModal.hide();
    $('#modalWaitMsg').show();
    $('#modalWarningMsg').hide();
    $('#modalCounterMsg').hide();
    $('#modalConfirmationMsg').hide();
    advertisementID = 0;
    secondsLoaded = 0;
    adLoaded = false;
    adConfirmed = false;
    adSessToken = null;
}