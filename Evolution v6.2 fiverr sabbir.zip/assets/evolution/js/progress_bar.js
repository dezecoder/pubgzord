progressBar = {
    object: '#progress_bar',
    seconds: 5,
    counter: 0,
    progressed: 0,
    progress_status: true,
    bar_status: 'paused',
    statusBar: function () {
        if(progressBar.progress_status !== true){
            return false;
        }
        progressBar.counter++;
        if(progressBar.counter < (progressBar.seconds*100)){
            if(progressBar.progressed < 100){
                progress_rate = 100/progressBar.seconds/100;
                progressBar.progressed += progress_rate;
                progress_round = Math.round(progressBar.progressed);
                $(progressBar.object)
                    .css("width", progress_round + "%")
                    .attr("aria-valuenow", progress_round);
            }
            setTimeout(progressBar.statusBar, 10);
        }else{
            progressBar.callback();
        }
    },
    start: function (seconds) {
        progressBar.seconds = seconds;
        setTimeout(progressBar.statusBar, 10);
    },
    pause: function () {
        progressBar.progress_status = false;
    },
    resume: function(){
        if(progressBar.progress_status !== true){
            progressBar.progress_status = true;
            setTimeout(progressBar.statusBar, 10);
        }
    },
    callback: function () {
    },
    setCallback: function (callback) {
        progressBar.callback = callback;
    },
    getStatus: function () {
        return progressBar.bar_status;
    }
}
