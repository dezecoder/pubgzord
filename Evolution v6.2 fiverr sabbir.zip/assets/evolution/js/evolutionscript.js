$(function(){
    checkall();
});

function checkall(){
    $('#checkall').change(function(){
        var checkboxes = $(this).closest('form').find('.checkall');
        if($(this).prop('checked')) {
            checkboxes.prop('checked', true);
        } else {
            checkboxes.prop('checked', false);
        }
    });

    $('#checkall2').change(function(){
        var checkboxes = $(this).closest('form').find('.checkall2');
        if($(this).prop('checked')) {
            checkboxes.prop('checked', true);
        } else {
            checkboxes.prop('checked', false);
        }
    });
}

function sowdeletionbar(){
	var referrals=$("input:checked[name^='ref']");
	var refslist=referrals.length;
	var raction = $("#descr").val();
	$("#priceref").hide();
	$("#priceref2").hide();
	$("#paybutton").hide();
	$("#addfunds").hide();
	if(refslist>0){
		$("#rentedbar").show();	
		if(raction == "delete"){
			var price = deletion_price*refslist;
			price = price.toFixed(3);
			var step1 = 'done';
		}
		if(step1 == 'done'){
			if(rental_balance >= price){
				$("#priceref").html(totaltopay+": $"+price);
				$("#priceref").show();
				$("#paybutton").show();
			}else{
				$("#priceref2").html(noenoughfunds);
				$("#priceref2").show();
			}
		}
	}else{
		$("#rentedbar").hide();	
	}
}

/* Allocate */
function calculatecredits(value){
	var newvalue = $("#allocate").val()*value;
	$("#creditcost").val(newvalue);	
}
function recalculatecredits(value){
	var newvalue = $("#creditcost").val()/value;
	$("#allocate").val(newvalue);		
}

/* Advertise */
function updatepack(){
	specialid = $("#spackformlist").val();
	specialtext = $("#spackformlist option[value="+specialid+"]").text();
	var packlist = "<strong>"+specialtext+"</strong>";
	packlist += '<ul>';
	for (var k in specialitemsList.specialitems){
		if(specialitemsList.specialitems[k].specialpack == specialid){
			packlist += "<li>"+specialitemsList.specialitems[k].amount+" "+specialitemsList.specialitems[k].title+"</li>";
		}
	}
	packlist += '<ul>';
	$("#specialpackdescr").html(packlist);
}

function advertiseItem(formModule, itemContainer='select')
{
	$('#Msgcheckoutform').remove();
	var formID = $('#'+formModule);
	const moduleName = formID.find('input[name="product"]').val();
	if(itemContainer === 'select'){
		itemID = formID.find('select[name="item"]').val();
		itemTXT = formID.find('select[name="item"]').children('[value="'+itemID+'"]').text();
	}else{
		itemTXT = formID.find('input[name="itemTXT"]').val();
	}
	$("#itemname").html(itemTXT);
	$("#productname").html(moduleName);
	$("#ads_list").hide();

	var payment_details = '';
	$.each(formID.serializeArray(), function(i, field) {
		payment_details += '<input type="hidden" name="'+field.name+'" id="'+field.name+'" value="'+field.value+'" />';
	});
	$("#checkoutform").append(payment_details);
	$("#payment_form").show();
	return false;
}

function cancel_payad(){
	$("#payment_form").hide();
	$("#ads_list").show();
}


/* Timer */
function dateTimer(){
	var hours=mydate.getHours();
	var minutes=mydate.getMinutes();
	var seconds=mydate.getSeconds();
	if(hours<10){ hours='0'+hours;}
	if(minutes<10){minutes='0'+minutes; }
	if(seconds<10){ seconds='0'+seconds; }
	fech=hours+":"+minutes+":"+seconds;
	$("#timenow").html(fech);
	mydate.setSeconds(mydate.getSeconds()+1);
	setTimeout("dateTimer()",1000);
}

/* Rent Referrals Options */
function showextensionbar(){
	var rented=$("input:checked[name^='ref']");
	var rentedlist=rented.length;
	var raction = $("#descr").val();
	$("#priceref").hide();
	$("#priceref2").hide();
	$("#paybutton").hide();
	$("#addfunds").hide();
	
	if(rentedlist>0){
		$("#rentedbar").show();	

		if(raction == ''){	
		}else
		if(raction == 'recycle'){
			var price = recycle_price*rentedlist;
			price = price.toFixed(3)							
		}else{
			var days = ref_extension[raction]/30;
			days = days.toFixed(2);
			var price = (renew_price*rentedlist)*days;
			var price = price - ((price*ref_discount[raction])/100);
			price = price.toFixed(3);
		}
		if(rental_balance >= price){
			$("#priceref").html(totaltopay+": $"+price);
			$("#priceref").show();
			$("#paybutton").show();
		}else{
			if(price != null){
			$("#priceref2").html(noenoughfunds);
			}
			$("#priceref2").show();
			$("#addfunds").show();
		}
	}else{
		$("#rentedbar").hide();	
	}
}


/* Ads Page */
function hideAdminAdvertisement(){
	$("#admin_advertisement").remove();
	$(".blockthis").l2unblock();
}
function hideAdvertisement(id){
	$("#"+id).addClass('disabled');
}

/* Style Picker */
var listStyle = ['blue','red','green','orange'];
function stylePicker(colorPicker)
{
	var finder = listStyle.find(e => e === colorPicker);
	if(typeof finder !== "undefined"){
		$('#bootstrapStyle').attr('href','/assets/components/bootstrap5/css/'+colorPicker+'.css');
		document.cookie="site_style="+colorPicker;
	}
}
function getCookieStyle()
{
	let name = "site_style=";
	let decodedCookie = decodeURIComponent(document.cookie);
	let ca = decodedCookie.split(';');
	for(let i = 0; i <ca.length; i++) {
		let c = ca[i];
		while (c.charAt(0) === ' ') {
			c = c.substring(1);
		}
		if (c.indexOf(name) === 0) {
			return c.substring(name.length, c.length);
		}
	}
	return "";
}
function captchareload(){}