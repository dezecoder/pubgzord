function lockTopic() {
    $("#topic_action").val('lockTopic');
    $("#topicForm").submit();
}

function deleteTopic(msg_id, topic_id) {
    if(msg_id == topic_id){
        msg = 'Do you really want to remove this topic and posts?';
    }else{
        msg = 'Do you really want to remove this post?';
    }
    if(confirm(msg)){
        $("#topic_action").val('deleteTopic');
        $("#message_id").val(msg_id);
        $("#topicForm").submit();
    }
}

function kickUser(user_id) {
    $("#topic_action").val('banUser');
    $("#message_id").val(user_id);
    $("#topicForm").submit();
}

function suspendUser(user_id) {
    $("#topic_action").val('suspendUser');
    $("#message_id").val(user_id);
    $("#topicForm").submit();
}