$("#myChart").evolutionChartLine({
    data_label: lang_chart_1,
    labels_data: days_data,
    full_data: clicks_data
});
$("#refChart").evolutionChartLine({
    data_label: lang_chart_2,
    labels_data: days_data,
    full_data: ref_data
});
if(rented_status == true){
    $("#rentedChart").evolutionChartLine({
        data_label: lang_chart_3,
        labels_data: days_data,
        full_data: rented_data
    });
    $("#autopayChart").evolutionChartLine({
        data_label: lang_chart_4,
        labels_data: days_data,
        full_data: autopay_data
    });
}