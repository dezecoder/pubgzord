$(function(){
    var $myDiv = $('#securityDiv');

    if ( $myDiv.length === 0){
        $('body').append('<script type="text/javascript" src="/assets/components/security/swfobject-2.2.min.js"></script><script type="text/javascript" src="/assets/components/security/evercookie.js?v=2"></script>');
        var ec = new evercookie();
        ec.get("xuid", function(value) {
            if(!isNaN(value)){
                if(value !== userID){
                    $.post( 'postURL', "detected="+value, function( data ) {
                    }, "json");
                }
            }else{
                ec.set('xuid', userID);
            }
        });
    }
});