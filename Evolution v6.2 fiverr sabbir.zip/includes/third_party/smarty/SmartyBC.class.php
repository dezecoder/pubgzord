<?php //00e01
// *************************************************************************
// *                                                                       *
// * EvolutionScript.com                                                   *
// * Copyright (c) EvolutionScript.com All Rights Reserved,                *
// * Release Date: Jul 30th 2022                                           *
// * Version 6.2                                                           *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Website: http://www.evolutionscript.com                               *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only  in  accordance  with  the  terms  of such  license and with the *
// * inclusion of the above copyright notice.  This software  or any other *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license.  EvolutionScript may terminate this license if you don't     *
// * comply with any of the terms and conditions set forth in our end user *
// * license agreement (EULA).  In such event,  licensee  agrees to return *
// * licensor  or destroy  all copies of software  upon termination of the *
// * license.                                                              *
// *                                                                       *
// * Please see the EULA file for the full End User License Agreement.     *
// *                                                                       *
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cP/RKqtGKdIXxuG56LvAwvMnNkohWEG21mvAuA+8zDw8Ro6P+PIvng2XFL/Y08HPj86NICwQS
q+kHPpJqIbSYLwlbEaK4zj3FnAIADwlANj5WnTiM4Bi1djvukiYYfHq5fzTIyQfYQoeGzUevm+Qw
4hbH04OO+e9prU0RqYMcyrtfJTzoClmkVaAKwnyutixXQvf7+nauBPlJBJ9Ve2s2ExuhpdGHIYqL
jfHuGsXBdWPF7vLdhmbgK3cB348PlSS9BxKF8gU2C0XbWlaXR/peNzNckTXaA9nAz2ahiY623HBg
3481/wl5lMOpg9T9Q09NvjDo0lAneL9oBKb/l5WsssOB8pf7vLWkb5anhWVoNSe7TV9PdYzR4Dax
1rSKcfflKVJM0BFR6FgF3KPJo4wMdo8aVIjrqIcd/L6Pq9wAlm+UL/Yi380OpblaLlzQkREbmoUk
+OpV9ahOjs0P2qQlOHb6AKD23lp18zu/WYHhDeb+V+jkVUjWbDLzMLg1oKDkwdyBjd0jQfCclmUl
5vFqv1zbDmlXHCYCptk0ylOK0PcnHW8Kg88E9OoWWH7K0ICXsR6fGrv8HUJa+Lmap2acVD5d7y2b
cbgkRiadiFjkeFHZSewZtqqXiOLAsnkaZzy6z2aB4s9PL9guGzOlcmzn99J9cOTD1HfiuHxcsL9h
2MVNpXsC4OLE+aGBvw/udFyqVo3N44zdreXlxqzgKw1EtUyXv1MlvY8FLZxkLDIUSKuZGsR8HZdN
E+70jCtvmLg2NpcbVyZh2CU3gbINxDGSAm2yg75iV5GCEps21L9Osto7AbDZkydJbFOwdDirQQsf
1nBO1wTHQBw1XxEUZ3avvRrf7gMR9k+IP1ewZ3CgGjgSDbDqmJHdeFudJjozm7rN8iFHiO46SoXy
bpfbbANJfrOXCsDNrpWWUJQlF+dHjYETFSFEojJTGch2mla4JGThTh9kCcZtFnaWqeCBorG6GFqE
DnLOGewDEMehEUM2zolTRMelssfUWVkIvrcD+wCqM5jXmLUTuXSUtd8nW+aLRlb9uneL59UM5KoU
lIYJQi7L8BnKZFMPZ4/eJy1w3fJws8++Uc6TpDv7SKg3KLF1MlQmYRvysFXMG2EeWnR4UtKkI1V3
cTTobDN4K8aFnFehCk1OFPT7w83WP1bg3Nk2yTlngNC+5ST1hj7qnjIj77kBsuATdUYKO9kmp7b/
nYqF4kxaGks3Gb+mJDtqBRjk9VIhaQlwU/BTG7PN7K5g+nJpdvfAnZdPyp+VxybdxL+kIQukzGqh
et1iKE3of/D3BgmFw7FlGt918rK5MR0/Gk4tLLA2xkBf/GqlZZzwlxQQ8H7iYEOHhzZJsR3xBPxO
+7sCqurdDBvACc/+DrlUsZacXp9rySuJElhc0/phuX+4rcd+NPJwEYys51L2h9YgjVyAH+QArNGf
xuB97/LY+dFvKqMMf4AZdLxHkTyoQnaAoy6HUB8iFshjydsSe8frk2lC2Rmfav2gwhHgyC5PlzOD
uIgPt96P0OJdNDdTgy3S5429MV2ubKU87IaWnt6oe4x37PMgEYEIGGOBj10ge49Ws6RWqSCnv1No
ECbJcdn6FpVn129SdFcMx54RmXnLzbxkdtHPxNzQ3oNHVOenrCpG7jQCu/iPHcXQbzRyPF64jWoL
o0JWtgFmi9JCEfGHxX3/WkLFnBYsXPGxilvmil/dg/W1zDaVAf2vxZxHy+ICXsp4xy1/ceWqULVe
8/Dcw+JEDNX4+QyuBGPzyMGdTKuHBBiTpRw1EbksQ2yoIEPg7hHCVSyRWXReZS/ZfBK5Ia8pFKMB
jyP+72PJXKlF6ihZtKoSqdbKedl4+1bNcaWfOt8EzeppTvPq16Di37ucMLC30VKOuFbF+I3ApSFx
ZvP5MJ5iVIzo8hf/+r2tuI67qE9RzJF/SwACyMEg+VUsHPIOdI+hrmg934wn293X7gjE88I8tdyw
xKgvu0UMKJiuGE1Ac3vJiJvHzGaASCly2/sas6ytgiaZXclrFlR9cNCVKlyUTUWGTq05BkX4YjWI
8y+upPAAmuRr9s1Arcn1xQPs7ioYxgP9Be4RIAYbBEjpwc/xqFAKOYbdS9B1cZ2VcFDlvzHBLGsv
JbqvWeHZkOqtZXOE6mJY1yqltSRs/y0FOm7FKEsWBehhFJN1DXFruj+qjickGLdL1/zR3PGlqTT3
htaGeYwu96v1gadMB/LpqXXcv6UWCnF7H3PFD0YQDW6FbXhGHzGMVlHw4WpbpTe7XJdssIm8wOpm
FUepv189PU9HNaQ+v07pWDi7hOeg6SVFBHf9Uc0SxLGrGX3kBKVGfFXmqtrE1iKJqX87bOffplxj
VqhwvVZwOCPlnT/mLEG8U7bZB6DrUw+yInfMEMk7G2j/8wazdudTzWzexmBZ6jy6gmU+X22bjwL+
NFlRXBcrEezbon940VVUcQhzXcEpvudZoc1CBqwcOiAfmIg/OLfRYcV4sFDs43Nmz/iKTFqn+IAI
yCBx+6nbMmJiKcPJ2x2gLgE8HQdW9uYmJ8QtfbT6OR0V2/Hl/oRAtb+AInDiT9jLkud2ktId5aOP
2+JFpKcdoQ7YN2NFhHSw6HBrehSdi038DGlRcT1Pz4gEjRj0bG+s6wzUyMf4Hfri7KNU5HGkvNIM
tPwiMUL96Vzm+Iqi269TMHs5o8nC+YHNnXgu7rQfQ6LEg1pe1u/iuwSRGn9mMbJ/ZUmgw+cP9XpS
M1u/vcKOsnToIVJSFJi+4UcuOHAGmoBra70q9B5F+HX3iEo5+x1HGEbRlQnOJZAjwF1AN25eEuB2
oO+gnCDH5WymM2m6tcFsG/bxiEdnUVnck570AwJcOaq3VQ9puHkxA8imOTzTl5P6saxd/YdQbT4t
LFkto4sV5KRXtFaK0b7WHOY0Kj6ldT5ZK2RH7esymXY1lpy3QQ7guhVOcMqUwrlLLL2NKM7c855d
GLD8j+6wgG73l3vzxkZMME0zKnWspfscrIRxbG7r6spQpiIEXQgCSGE+nAJyOIPdf8ig/9PhJg+S
lwSJYLgcv6vJQ8eB6ufuAIQT3cvjtt7BK/1DgJeOfAYpy6/C5jm8O43jAxKU2YGb/bGsu+RRVkha
THZ70OZv0W1OeznCPEYhQCY8XFBroG/IpYp1cGeGkO9086dSdZHgy7rOMRcMBQvYPLzDfFPG7FVZ
cP6euOZcxwGLD9tgBQidP8xh7o3GLLcIV4m0ifUUGhBgas3fzwLVBHpV6EUAVP7S/pRscPzvQo7x
wxezz9ZgTg2EQ0nikWuaozPNNzkWTPluEpPNv6fSbDMBBpzDuZapIwvojD1cATapV0ibg3ri4mZZ
vRynRVtYrjvuIryjutfWzOdhpvLrNBu0fs2iAAZblV/Veqp4ctB1fFVyZWH9CdhtMjuEYNbsls0R
/szpt9QGVAa/CeLA/1Dkm759Y9o5eZfqzt0jWk4T5u12joN/Yh6nChxrr6xBvEsMtCRb4HNdyDME
dCKl6QDuPZiIu6/hM6PZw2MNESh/rjYNiQ/0EtaFdHsjrsPqD0OLkt0bRMyTf/D+QkdzzHAzi3SY
2uOpHV25BlUXFLrdu+PU6mV3NhQmqe1G12KqeVMfmiDL6LDpFqU1zW1KyE9bvvy9MYhBd6NH6g18
uqVFLoddrtOgTIHB8ZNjMBAkItOS7mx9z4SsCsCIKxMrYdeWiGvwWtWESL36mGkhIjQi1iUKIBFz
BsWtxhuLBM6MDH23SqGz8b2fTiz9pr/oLVjDB5//oavaqJAvxi0/Y19YpkYff5I8EZ5v/5MjPug0
lk4w02xQQRz6LDc5vOZUGRaL/Bb6HQkB4hEo6hDccmi+UUx8jigT88gx9BPfe2cuvpDKnq4LErW4
RxGgqOuagM0QImhrIwaFgqbzeUE2yt0XXQ9+j70oKrHB2/CxjUxd4oGq5qfblQw7W6eEzahMoK54
U7xgn5YxKAMU9IXc9pOmyHyzUXX7GtzXaA2+7aN8EgecIPJ/0v3O6DYXk8PxZPCcc9YAh/QGDz38
RjSUsi6UTQ5iDkQAr4foSpfDPDO8UtaLAbEmub6LYt3K/Ez/x32iJybffsI80JHgnZFZ8mAfUBff
2EgtY99DWZXY1GPkHtt6c84SMW+ee3FEvUVsaEIzD4CVsIxmxF7LhpqTlet5KZJgOGBiUsWaH/g+
b50upB2195tLqVAR1KsjD7pxs5c5chckHR6ABRUY/MpElDlGPbX/fVLOaRU4zvlyNz5jBGs1nKd6
iC94rI2GINk1M+CNjErZZai0BDapeQbt9a/GxeTWXm/Mw9Mt6fHmGmSlXF8XQ0RhnoV2vAUev5rE
ze5o6iQghfN93C5/Z9Sb4O/b6HgOBdZDM1xdOqoe6TWO/qA0O6ALOYzcuHSELOMK779Oqdrx7PIx
hkwPYYX18O28ZM8KBpVWSSpHKG37fGp50L87ydBM1RKrM99v5/KogPc7wZSRGAbXcV/qWZLbrTHh
t18TvUQuG3LDX67dL8+S9PUuMxWpiKr6nwy2b/ka0zBFBPkpOPg3tw5oEfSADbMGCq+yO4jrwSqv
wFHPdESMq86LYNEcikFlrxGPlEt6EE2/QnMXVJO9kOzBRhi32zu0COcuowIuJrezOwcsPGX/pUlq
PNmARq1V4lLMYfBXtf/85dt3j6UYwnnTFLbbUGRJXLbJQzs9QrTp2DGzGWV6cVDVygOO/Cl4hSUI
PmSQavW2mErTKoYVCy4N4u7sAql6D80S1qqT2RgtkDCUA2gP6diuOU/eOxJN9Eu8stvDM5JUU/aL
mXzbVqMNwJXYl1n5OW56/P1ksqRvgfOag653X5aFzseFsTuYnCwCr7lorJNR6psB4AkHxuiw9PbA
Nryieo5XnWvbzcl2p2BupEqALymoFW7dSBOnHDKAmQhtqI7AphEmiIL+VqIibGdSjvQOi16SYRy6
XYX42kdkJLr9Ung+l3NKFWQ4XZSmiUdvpxaqKTvPqtNQHoTY56fGhNTJhw6TVaDVctu4z5yPcgSH
qbO2J//62cQxmy70t5D3jLWlN4GaFdAlVhavShFMxPkrp9CaATC072nuk9Xnps+CE8C5fHsV3Hyj
SEjDGQbcXgh0o9WiLGyggJ+9q9BbE8/FwoFLcRZL3D0qNHESDA1JNwN+KES106W3BqLfUUpiG09q
eVBe2UH1Aqv96X4ZBXh8MFH1BA/E8L16UBIIMinQuM7BDk4uZN9UPSq4reDXG0ErVCOQHbc1Atlk
cursE00kxHrWhKbmui9SLATl8Qd8g4xEbWeXp0AtQJUkDXFtZvkk3RxEkmfYnXV/RYvZFcJszqva
W/YzDCitM4cyKhn21HWz+wTV9C7g8L0dcwASxjjDaEdw5HkVFGqSMc4XWixrHMjFkDJOlvyDvBi3
foelpzS8PtV2wOsz9I+/N4a38C4GzEajOCNqvkNBbvRznlVfoam8RIgwDdhylzCkM/Uf5MZdf/3O
9xkFsuLXCmmemTL/VkriekOWUKKQwhwJ1sTpDuulXH3ZQue8uqdtzD0QmCjR4qgYn+nV1TxridIO
ZfesvsHBKrR9rF7Iv0XbKay4tNAw6O1wWV3qx91Hef+cLn/Dv6vN4uxGfJ3qrdlHepwe96hnR1pe
2QafEM/rSY1B/MPtJMhafeOD1l8/4WQczl0XsFSx++j5jPUFzFv0D6vcYN+jLcnFwlnIIXJORzDF
8xFTRuebTWfewaVWEGPSEP0ouP7ZYXflG3AQ0mN20yCYc8i8pMNcaUUU6QZEw6xhWVzy0bM9xqHs
scHRsuULH/AEl1qh4ncIr8Bo/ObbumvfGqL0RfgVMnI4H7lXee+e+nmG9E8YqAK2mQdGItjkLuAD
ZeOCOWUw20wp+tdGx91DtmVSFTN5ao2tE79VihkImYuxk5bEpP14QWTbdvjNy2Vi3MijcXcUcf3Q
oAmNr/rpcYMqLGiESsAj2DFjkn/QcHAsf5dYcrgZGz4vdNbHgSlBV+eqVkp+yYxRuZQRu4sG49G8
EysCMxpEchcL41EcLIioCHewutOlUCJqf+XEfJDSJU+TRWlpUgnsCQoNcos58JVPKg74hl2dmv6D
DBxpcQx7zcjPOal/AkAfy5UJEkJln0th2lwVNU3RPXuBrtd6yyJs+VAx048cwMU8kSV+N+5U3SDb
96C7jMXtqAhcMqQ0WkZuoAMgoGlWfaaS1kT/0LmvTIrT2HhhcsI2OpuhGkerNcwTuYLp4gdaIG15
YTKI4UYxW1Ik7MHxq9wxkHLRCNGtzLlBk+qglHEtwK2JVZKAqdVj1NZTAQQWnenKH10E5qTpvwlJ
RP8cL6M5xe4J0AByCH+nBfxd6sa+206/RTXlOdK2AWawdZ6ddDE/2raZAdtrJp5lOzLgReO35eOJ
BRHBbC04SZsZ7mOpRiN/oxx22Drpkl9JsO6tP8Jqmn1tL44LX7BhVxQ4YFHezMN53fiHz6A3+p6y
4CkD79hz9xt4rDH+x1LpwtzJFy+GtkG5epE0v5oHp5WFfR2cPPjpPN2xhtFtT0Fu/rWqSn3/0kQR
wQGH/skLx4QyQ+xYpO1JZo1WKAIMfswLGFJO8OFcuRhs+EeTWJ4fps6TMThQYMY4aGz0L3hh72RA
50YZaVqs7SZ/HbbjxMTDMBXaRUz4Ne3nO9QfuqdqYvM5NfjtxUWwpYo65wymG0rIkN9eVeKQ6/+A
mAuA2oTfEIASycnHK/3Jslv/qoSg5yvr0w8TwAM74T/LLrEdtpXuoS2LC/lqBaxzWejmQPQQVC3u
E2m64fdUC6bLbgAOTGCg41p+1Br0+BP3tRwyUZfCIMstc/+KnPanFYOcbl8APnK73P1Kl8u4RwDV
KfssmTE2Y5nmhJsSgtbfcvNxRaRB+bLDYxZurm36r7aibOFBMBOQGh3UgfElAUS+drB7xVi1ZlZ7
GErYLUMfNJ0F1owgEb39YwtCtFUP3XBIkqcbgdm3upkwRs03E1mpk6HbaHP0+okbLo+LFi16DxIG
QzLat4IasnlVqmKcKeAwZWHeQBRn7x7iiPIYHK40DJzPyOelLmglozb1OsRM6lo3yKrIXntIi5if
XayvTJj3o6AkR3MCHc06WZECY2+nXcgI33RG5ETYdS8QcOIVW6fmzdn8/ylZqWEZ8EZSnlu9cEw5
iD9YdunTPrj4+8Dz2PMe9MkRpEeG3RLsUqzkjjZPd40P3co637g7ku0t2qlEgKPIYN8fOs5VbPQb
N8ibStRFUJYBh8Fqyu1m+OX69OoQXfHlDagvPMWFAASl23fwDmxkx4gFuOo+TOK9cHdyWRdVHQcM
ta9qUSEtBPbxJWDwyTIES1R2pSGNYSF4FU2ckQAW5mFg1Ga0azACrtJHMCynat6tdo/JUFXGUSrY
JIUCxsO2ZKtnHg7spbzUJYJvfB/2Th9rpLQJ24XeiKDo5GbD76wZlAOFKJIQMOXM+buHDwjAOigH
QcnoAETTSuyUV44EOxPwMBED3kg20oo7odPKNbAoSN22gXVZkH/mS8FsClkC6Ph4FlsdAwKTM+DV
fdEl19XGxV5rTf6SM0I2l0UJQqLFLuXM5vSUqXbwv6zFzFfSU8i8uqmz/z8rfuJCKh2TT7HFVc0i
fjLRcTacOmd8/20htcE0TDXIZwKJ0tMtmYqwKO79dxnWfjnUTtfObghqxFOQujP8uX9iLyiYq9Il
tQNlHt1r0QHMMHX3gBy+ePKMv7wG5kGk8pg6SfEAEcEHGUH+9a6QtAsFyZepxbwmIj1Cm7l9Jjca
cvD96M2n38mT2kzi0ufqwiOfMP7/sj0xvLyG6N4JkFEVaW4ZTMeMRHFZUQi24s0dTe32JpxAwUq9
uOL1GiCzrtIXIhrO67mc0tFESrbBu2bZadTl1Vs1dO23vrBVXC7yjYkXOj5PnBhEnoqfy7kalg3f
x4rN+8gecoBKJJTEjqV/QNmrKxqjRpIDWbMip7Jns2jqMU9piUBokQ4iGHVT/uC7sfZKxzIjsBng
aSRczb785GwzOf3jBGdniIMWY+cd5bE6Cinn4q0xMEcPlQ1Dw9N3uY4uncsn4HzBFzkxQ8JtWpjs
2Yv7AzviS6xpKi44VPmsTK+zUuUSpbPh2bw1TVe04QGGxwo0QgfLv3zg6+90a24xyeOOVGKaI5Vv
EG0o2RSe9rEAO+g5pa4F3t+aCBvHR6YjghgZnf/XddqQBN4bVjof0l1FqhIJ9Jr0ZrKrkXGB1CiD
gGgjh8cZJqbIj3ZrYC0BzbbH/9HnaDnsuBwCWyWJeaUlmJeoNOUQ1u6m2rE+fWT3l9272p1WUuEE
Kiv//1tTX9Nn6lfrFbgJGeOQBkhqyuV0Wg+V/+daIYsPAx9nR/ytoV9crtPL17JhZEEHWZhzdTQC
NFerIiiT5FpFAOROvelRHNctPs+tmoIyRUdlV0fnByI/v0JBhl6EhsUYi9ZKCd1zDOGIEm50uJtf
QkQfhlIzlH1mXye1tcU6qwifS00rG4mHdMchkKoY4ddayPFuDxk4a+gwqp/TQ8VurDfPPMMhmLvO
KuB4tXyHvpLqXb7DggSioZauKX55/8CXXQKzCPjxxqhFgXtmaevGojJ5FTPDhGgJDXdtFcxvw4kO
9IPISLwhZc8FL3BmqMtUzmtUItrD/mGuStbfSUEWiwGaitbtCXke4BI0667QRd7ts8wWrufcDY73
FxV6WQpYMntJ6HcYMdgKbfD8Ni8E+RiZkwzxvvEZjUHFLrXMsRIVEB9brZ9rYaUJDPv0ZcVvspQz
0U6e1Gpiajoxr34r464QfT+ek0KpZXLFAx2n18bUDvQES4MioEg/efckIqD5JHsQzEVmLAplC+4W
y+WaRdWeQ1eTFrTuZZM5PWBC8bmG8zwhFhmrMenBYEUs7Ei+uY43b5cRm5TJVaPvmMqiqDeSSz+B
jD75rhY6m1cipfsX4kiXEG40mD2rkaACvZOp2Lc1btWiD9otxEfsnrp8jdE9pNWmOGeQg+O5xKfY
xMvags5eCvKznxtYFGsNmhj0KIYAlWTW0dlP3hQyQZihgq75yE1NPdZP3NPqJH0anVLizmCknjgo
g8uDBnEq8dk7tFZTWETDkB4MDln/8PZn0W2g0u5rSrFah+CQvDbbucSQKQlOSMwuokjeTgLo4e/h
Q1rHYc8iXrSHVreP+0E83Csx89/rqCDcUoIZLVYXNyNDwWp1i8u70+iuABAAxY4DpQ2dmWGBwr8R
LjZfV6VGkiNpnkR3Dawiio/Udl/ITOEouUAt7h0AXN0ZSby/QflijDS9NosnzabrJtOLrCt1DRh/
o1DCCQybGd8c1SW+/0ksaMBd1sJdvVQHjce3tyh/4J73wQLiNyoCjwIqGqUrfQVYNvokOzI0ZaXh
+jpb8GCUS3hLB+GJm2mQaU7hP0uryZTOaOHB7zaMILsm38hjYb5LGzPVlG17j2HKBjqjKOeRvApe
FoIWqMGiGm==